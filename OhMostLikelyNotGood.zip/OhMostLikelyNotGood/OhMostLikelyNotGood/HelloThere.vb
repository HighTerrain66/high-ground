﻿' By Oliver Hill, otherwise known as HighTerrain66
' This the Beta build of a piece of software designed to aid in one's education in quotes from the Star Wars prequels. The reply version(this one), was the first to be made, but I then completely focused on developing the image version leading it to be more advanced. Now I've made the same advancements to this version, pushing it into the Beta stage. Therefore, it has less comments so if you want to know how some of the parts work look at HelloThereImage.vb instead of this.
'-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
'          _______  _        _        _______ 
'|\     /|(  ____ \( \      ( \      (  ___  )
'| )   ( || (    \/| (      | (      | (   ) |
'| (___) || (__    | |      | |      | |   | |
'|  ___  ||  __)   | |      | |      | |   | |
'| (   ) || (      | |      | |      | |   | |
'| )   ( || (____/\| (____/\| (____/\| (___) |
'|/     \|(_______/(_______/(_______/(_______)
' _______           _______  _______  _______  _ 
'\__   __/|\     /|(  ____ \(  ____ )(  ____ \( )
'   ) (   | )   ( || (    \/| (    )|| (    \/| |
'   | |   | (___) || (__    | (____)|| (__    | |
'   | |   |  ___  ||  __)   |     __)|  __)   | |
'   | |   | (   ) || (      | (\ (   | (      (_)
'   | |   | )   ( || (____/\| ) \ \__| (____/\ _ 
'   )_(   |/     \|(_______/|/   \__/(_______/(_)
'-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
' If you do not know prequel quotes and for some odd reason do not wish to watch the glorious films known as the prequels in order to become a truly cultured man, here are the replies you'll need:
' Hello there!-General Kenobi!
' The Senate will decide your fate-I am the Senate
' I have brought peace, freedom, justice and security to my new empire-Your new empire?
' Oh, by the way, I think you'll be needing this-Thank you Cody
' Execute Order 66-Yes my Lord
' My powers have doubled since the last time we met count-Good. Twice the pride, double the fall
' You are on this council, but we do not grant you the rank of master-What? This is outrageous. It's unfair!
' I'm not bothered to add any more to this list so WATCH THE PREQUELS AND COMPLETE YOUR LIFE
Public Class HelloThere

    Public Declare Sub Sleep Lib "kernel32" Alias "Sleep" (ByVal dwMilliseconds As Long)
    Dim stage As Integer = 1 ' stage determines which reply must be used to move to the next stage
    Dim oldStage As Integer = 1
    Dim ran As Integer = 0 ' random integer used to determine the next stage
    Dim ran2 As Integer = 0 ' radnom integer used to determine the correctLbl text upon a correct reply
    Dim currentSize As Double
    Dim completed(0) As Integer
    Dim score As Integer = 0
    Dim fail As Integer '  a random number that determines what reply the user will receive upon answering incorrectly
    Dim counter As Integer ' increases by 1 every 1000ms, determines the penalty to score received when an answer is entered late. is reset when a quote is entered.
    Dim WithEvents Timer1 As New Timer ' the timer object that ticks every 1000ms and increases the counter by 1 each time
    Dim penalty As Integer = 0 ' is determined by the counter variable then is subtracted from the score gained after a correct quote is entered
    Dim oldScore As Integer = 0 ' is used to compare the score before addition to the score after addition to ensure that the score won't be reduced on a correct answer
    Dim totalCount As Integer = 0
    Dim correctTime As Integer = 0
    Dim nearish As Boolean = False

    Sub Start()
        StartBtn.Text = CStr(CInt(StartBtn.Text) - 1) ' decrements the counter on the start button
        If counter > 2 Then ' if the main counter's value is greater than 2(if 3 seconds have passed since the clicking of the submit button)
            counter = 0 ' resets the main counter
            Button1.Enabled = True ' enables the submit button, effectively starting the test
            CounterLbl.Text = "0"
            CounterLbl.Visible = True ' makes the counter display visible
            StartBtn.Dispose() ' unloads all assets relevant to the start button
            TitleLbl2.Dispose() ' guess
            TitleLbl.Text = "Hello there!"
            totalCount = 0 ' resets the total count so the 3 second in which the user cannot submit an answer are not counted
        End If

    End Sub
    Sub Proceed()
        Randomize()
        Console.WriteLine(completed.Length)
        oldStage = stage
        If completed.Length < 12 Then
            Console.WriteLine("Main sequence")
            Do Until False
                ran = CInt((12 - 2 + 1) * Rnd() + 2)
                If Array.IndexOf(completed, ran) < 0 Then
                    Console.WriteLine("Not yet done")
                    stage = ran
                    If stage <> oldStage Then
                        Exit Do
                    End If
                    Console.WriteLine("Not yet done")
                End If
                Console.WriteLine("Already done")
            Loop
        Else
            Timer1.Stop()
            Me.ScoreLbl.Location = New System.Drawing.Point(97, 102)
            CounterLbl.Text = "Total time taken: " & totalCount
            If score < 0 Then ' all of these lines are for ranking; a score between 1301 and 1200 will give one a seat on the council, but they will not be granted the rank of master
                ScoreLbl.Text = "Rank: So uncivilised"
            ElseIf score < 451 And score > -1 Then
                ScoreLbl.Text = "Rank: Youngling"
            ElseIf score < 801 And score > 450 Then
                ScoreLbl.Text = "Rank: Padawan"
            ElseIf score < 1201 And score > 800 Then
                ScoreLbl.Text = "Rank: Jedi Knight"
            ElseIf score < 1301 And score > 1200 Then
                ScoreLbl.Text = "Rank: On the council but not a master"
            ElseIf score < 1501 And score > 1300 Then
                ScoreLbl.Text = "Rank: Jedi Master"
            ElseIf score < 1800 And score > 1500 Then
                ScoreLbl.Text = "Rank: Council member"
            Else
                ScoreLbl.Text = "Rank: The Chosen One"
            End If
            If score > 700 Then 'the user is given the oppurtunity to enter a certain quote for even more points if they got more than 700 score
                stage = 20
            End If
            'Help()

        End If
        Console.WriteLine("Proceeding")
        Console.WriteLine(oldStage)
        Console.WriteLine(stage)
        Console.WriteLine("---------------------------------")

        If stage = 2 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "The Senate will decide your fate"
        ElseIf stage = 3 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "I have brought peace, freedom, justice and security to my new empire"
        ElseIf stage = 4 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "Oh by the way, I think you'll be needing this"
        ElseIf stage = 5 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "Execute Order 66"
        ElseIf stage = 6 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "My powers have doubled since the last time we met, Count"
        ElseIf stage = 7 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "We do not have many ships to spare"
        ElseIf stage = 8 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "The oppression of the sith will never return. You have lost."
        ElseIf stage = 9 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "Your clones are very impressive. You must be very proud."
        ElseIf stage = 10 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "Credits will do fine"
        ElseIf stage = 11 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "We lost something"
        ElseIf stage = 12 Then
            currentSize = TitleLbl.Font.Size
            currentSize = 17.0F
            TitleLbl.Font = New Font(Label1.Font.Name, currentSize, Label1.Font.Style, Label1.Font.Unit)
            TitleLbl.Text = "You are on this council, but we do not grant you the rank of master"
        ElseIf stage = 20 Then
            TitleLbl.Text = "We must admit that without the clones, it would not have been a victory"
            Button1.Text = "(you won?)"
        End If
    End Sub
    Sub Nter()
        oldScore = score
        If stage = 1 And UCase(TextBox1.Text) = "GENERAL KENOBI!" Or UCase(TextBox1.Text) = "GENERAL KENOBI" Then 'if stage 1 is fulfilled by entering the correct reply
            Lbl2.BackColor = Color.FromName("White")
            Lbl2.Text = "General Kenobi!"
            TextBox1.Text = "" ' clears the textbox
            completed(0) = 1 ' adds stage one to the list of completed stages
            If counter > 5 Then ' penalises the score if the user has taken more than 5 seconds
                penalty = 400 * (0.15 * (counter - 3)) ' sets the penalty to 15% of the highest score possibly obtained multiplied by the counter value -3
            End If
            score += 400 - penalty ' the score is added to by the highest possible score with the penalty (if there is one) subtracted from it
            If score < oldScore - 0 Then score = oldScore - 0 ' this stops score from being subtracted upon a correct answer
            counter = 0 ' the counter is reset
            penalty = 0 ' and the penalty is reset

        ElseIf stage = 2 And (UCase(TextBox1.Text) = "I AM THE SENATE" Or UCase(TextBox1.Text) = "I AM THE SENATE!" Or UCase(TextBox1.Text) = "I AM THE SENATE.") Then 'if stage 2 is fulfilled by entering the correct reply
            Lbl2.Text = "Not yet"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 2
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 3 And UCase(TextBox1.Text) = "YOUR NEW EMPIRE?" Then 'if stage 3 is fulfilled by entering the correct reply
            Lbl2.Text = "I do not fear the dark side as you do"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 3
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 4 And (UCase(TextBox1.Text) = "THANK YOU CODY" Or UCase(TextBox1.Text) = "THANK YOU CODY." Or UCase(TextBox1.Text) = "THANK YOU CODY!") Then 'if stage 4 is fulfilled by entering the correct reply
            Lbl2.Text = "What would I ever do without you?"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 4
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 5 And (UCase(TextBox1.Text) = "YES MY LORD" Or UCase(TextBox1.Text) = "IT WILL BE DONE MY LORD" Or UCase(TextBox1.Text) = "YES MY LORD." Or UCase(TextBox1.Text) = "IT WILL BE DONE MY LORD.") Then ' I'm not bothered to do a comment for everything
            Lbl2.Text = "*laughs in sith lord*"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 5
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 6 And (UCase(TextBox1.Text) = "GOOD. TWICE THE PRIDE, DOUBLE THE FALL" Or UCase(TextBox1.Text) = "GOOD. TWICE THE PRIDE, DOUBLE THE FALL." Or UCase(TextBox1.Text) = "GOOD, TWICE THE PRIDE, DOUBLE THE FALL" Or UCase(TextBox1.Text) = "GOOD, TWICE THE PRIDE, DOUBLE THE FALL." Or UCase(TextBox1.Text) = "GOOD TWICE THE PRIDE DOUBLE THE FALL") Then
            Lbl2.Text = "2Pride2Fall"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 6
            If counter > 8 Then
                penalty = 200 * (0.15 * (counter - 7))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 7 And UCase(TextBox1.Text) = "WHAT ABOUT THE DROID ATTACK ON THE WOOKIEES?" Then
            Lbl2.Text = "It is critical we send an attack group there immediately"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 7
            If counter > 8 Then
                penalty = 200 * (0.15 * (counter - 7))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 8 And UCase(TextBox1.Text) = "NO, NO, YOU WILL DIE!" Then
            Lbl2.Text = "P = 9999999GW"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 8
            If counter > 6 Then
                penalty = 200 * (0.15 * (counter - 5))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 9 And (UCase(TextBox1.Text) = "I'M JUST A SIMPLE MAN TRYING TO MAKE MY WAY IN THE UNIVERSE" Or UCase(TextBox1.Text) = "I'M JUST A SIMPLE MAN TRYING TO MAKE MY WAY IN THE UNIVERSE.") Or UCase(TextBox1.Text) = "I'M JUST A SIMPLE MAN, TRYING TO MAKE MY WAY IN THE UNIVERSE." Or UCase(TextBox1.Text) = "I'M JUST A SIMPLE MAN, TRYING TO MAKE MY WAY IN THE UNIVERSE" Then
            Lbl2.Text = "Convincing."
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 9
            If counter > 10 Then
                penalty = 200 * (0.15 * (counter - 9))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 10 And (UCase(TextBox1.Text) = "NO, THEY WONTAH" Or UCase(TextBox1.Text) = "NO, THEY WONTAH!" Or UCase(TextBox1.Text) = "NO, THEY WON'TAH!" Or UCase(TextBox1.Text) = "NO, THEY WONT'AH") Then
            Lbl2.Text = "Jedi rekt"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 10
            If counter > 5 Then
                penalty = 200 * (0.2 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 11 And (UCase(TextBox1.Text) = "NOT TO WORRY, WE ARE STILL FLYING HALF A SHIP" Or UCase(TextBox1.Text) = "NOT TO WORRY, WE ARE STILL FLYING HALF A SHIP." Or UCase(TextBox1.Text) = "NOT TO WORRY, WE'RE STILL FLYING HALF A SHIP" Or UCase(TextBox1.Text) = "NOT TO WORRY, WE'RE STILL FLYING HALF A SHIP.") Then
            Lbl2.Text = "happy landing incoming"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 11
            If counter > 7 Then
                penalty = 200 * (0.15 * (counter - 5))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 12 And (UCase(TextBox1.Text) = "WHAT? THIS IS OUTRAGEOUS. IT'S UNFAIR." Or UCase(TextBox1.Text) = "WHAT? THIS IS OUTRAGEOUS! IT'S UNFAIR!" Or UCase(TextBox1.Text) = "WHAT? THIS IS OUTRAGEOUS. IT'S UNFAIR" Or UCase(TextBox1.Text) = "WHAT? THIS IS OUTRAGEOUS. IT'S UNFAIR!" Or UCase(TextBox1.Text) = "WHAT? THIS IS OUTRAGEOUS, IT'S UNFAIR!" Or UCase(TextBox1.Text) = "WHAT? THIS IS OUTRAGEOUS, IT'S UNFAIR.") Then
            Lbl2.Text = "TAKE A SEAT"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 12
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
        ElseIf stage = 12 And (UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS. IT'S UNFAIR." Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS! IT'S UNFAIR!" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS. IT'S UNFAIR" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS. IT'S UNFAIR!" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS, IT'S UNFAIR!" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS, IT'S UNFAIR.") Then
            Lbl2.Text = "TAKE A SEAT" ' If the user missed out the WHAT? in the reply
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 12
            If counter > 5 Then
                penalty = 100 * (0.15 * (counter - 4))
            End If
            score += 100 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0
            nearish = True
            CorrectLbl.Text = "We were this close to perfection"
            CorrectLbl.Visible = True
            correctTime = 2
        ElseIf stage = 20 And UCase(TextBox1.Text) = "VICTORY YOU SAY OBI-WAN?" Or UCase(TextBox1.Text) = "VICTORY YOU SAY OBI WAN?" Then
            Lbl2.Text = "No, not victory. Begun, the Clone Wars have."
            score += 200
        Else 'if an incorrect reply is submitted
            If stage = 8 Then
                TextBox1.Text = "TAKE A SEAT"
                Threading.Thread.Sleep(1000) 'the user is forced to TAKE A SEAT
            Else
                Randomize()
                fail = CInt((100 - 1 + 1) * Rnd() + 1)
                If fail < 50 Then
                    TextBox1.Text = "Invalid answer"
                ElseIf fail < 90 Then
                    TextBox1.Text = "General Misquoti!"
                Else
                    TextBox1.Text = "The ability to speak does not make you intelligent."
                End If
                ReDim Preserve completed(completed.Length + 1)
                completed(completed.Length - 1) = stage
                'failed = stage
            End If
            score -= 50
            counter = 0
        End If
        ScoreLbl.Text = "Score: " + CStr(score)
        If Not (score < oldScore And nearish!= True) Then
            Randomize()
            ran2 = CInt((5 - 1 + 1) * Rnd() + 1)
            If ran2 = 1 Then
                CorrectLbl.Text = "GOOOOOOOD..."
            ElseIf ran2 = 2 Then
                CorrectLbl.Text = "Don't get cocky!"
            ElseIf ran2 = 3 Then
                CorrectLbl.Text = "A surprise to be sure, but a welcome one"
            ElseIf ran2 = 4 Then
                CorrectLbl.Text = "Ah, victory"
            Else
                CorrectLbl.Text = "Another happy landing"
            End If
            CorrectLbl.Visible = True
            correctTime = 2
        End If
        Proceed()
        If stage = 20 Then
            If score < 0 Then ' all of these lines are for ranking; a score between 1301 and 1200 will give one a seat on the council, but they will not be granted the rank of master
                ScoreLbl.Text = "Rank: So uncivilised"
            ElseIf score < 451 And score > -1 Then
                ScoreLbl.Text = "Rank: Youngling"
            ElseIf score < 801 And score > 450 Then
                ScoreLbl.Text = "Rank: Padawan"
            ElseIf score < 1201 And score > 800 Then
                ScoreLbl.Text = "Rank: Jedi Knight"
            ElseIf score < 1301 And score > 1200 Then
                ScoreLbl.Text = "Rank: On the council but not a master"
            ElseIf score < 1501 And score > 1300 Then
                ScoreLbl.Text = "Rank: Jedi Master"
            ElseIf score < 1800 And score > 1500 Then
                ScoreLbl.Text = "Rank: Council member"
            Else
                ScoreLbl.Text = "Rank: The Chosen One"
            End If
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click ' the reply button click event
        Dim Button1 As Button = DirectCast(sender, Button)
        Nter()
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            Nter()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick ' called every 1000ms
        counter = counter + 1 ' increases the counter by 1
        totalCount += 1 ' increase the total counter shown at the end by 1
        CounterLbl.Text = counter ' sets the text of the label used to display the counter's value to the value of the counter
        If Button1.Enabled = False Then ' if the test hasn't started yet
            Start() ' calls the start function which decrements the text on the start button and starts the test when the counter reaches 
        End If
        If correctTime > 0 Then
            correctTime -= 1
            If correctTime = 0 Then
                CorrectLbl.Visible = False
            End If
        End If
    End Sub
    Private Sub StartBtn_Click(sender As Object, e As EventArgs) Handles StartBtn.Click ' when the start button is clicked(the first time)
        If ScoreLbl.Visible = False Then
            InfoLbl1.Dispose() 'removes all assets for the first info label
            InfoLbl2.Dispose() ' removes all assets for the second info label
            InfoLbl3.Dispose() ' guess
            ScoreLbl.Visible = True ' makes the score label visible
            TextBox1.Visible = True ' enables the textbox so you can see it and enter text in it
            Button1.Visible = True ' makes the submit button visible
            Button1.Enabled = False ' stops the submit button from working so a quote can't be submitted
            Label1.Visible = True ' guess again
            TitleLbl2.Dispose()
            TitleLbl.Visible = True
            TitleLbl.Text = "Get ready!" ' guess yet again
            Timer1.Interval = 1000 ' sets the timer to tick every 1000ms
            Timer1.Start() ' starts the timer
            TextBox1.Select() ' selects the text box automatically for the user
            StartBtn.Text = "4" ' sets the text of the start button to 4, not 3 as the value is subtracted from almost straight away, but it needs to be an integer in the first place to be subtracted from
            Start() ' calls the start function which decrements the text on the start button and starts the test when the counter reaches 
        End If
    End Sub

End Class
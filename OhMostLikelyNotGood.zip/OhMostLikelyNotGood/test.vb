﻿Imports Microsoft.VisualBasic

Public Class Class1
    Dim arr(2) As Integer
    arr(0) = 4
    Dim boolll As Boolean = IndexOf(arr, 4)
    Console.WriteLine(boolll)
End Class

    import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
    
    /**
    * The player's spacecraft, featuring two heavy laser cannons which launch highly energetic ionised gas at high speed.
    * 
    * Oliver Hill
    * v0.2
    */
    public class Player extends Actor
    {
    /**
     * Act - do whatever the player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int speed = 5;// player's movespeed, is currently a constant
    private int load1 = 0;
    private int charge = 0;
    private int image = 1;
    public void addedToWorld(World MyWorld) {
        
    }
    public void act() 
    {
        Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
        Shield shield = (Shield)getWorld().getObjects(Shield.class).get(0);
        if (Greenfoot.isKeyDown("space") && counter.active == true) {
            if (load1 < 1) {
                if (shield.hull > 2) {
                    changeImg(1, true);
                }
                else {
                    changeImg(2, true);
                }
                charge += 1;
                if (charge > 30) {
                    charge = 0;
                    Shot Shot = new Shot();
                    getWorld().addObject(Shot,getX(),getY()-10);
                    load1 = 50;
                    if (shield.hull > 2) {
                        changeImg(1, false);
                    }
                    else {
                        changeImg(2, false);
                    }
                }
            }
        }
        if (!(Greenfoot.isKeyDown("space"))) {
            if (shield.hull > 2) {
                changeImg(1, false);
            }
            else {
                changeImg(2, false);
            }
        }
        if (Greenfoot.isKeyDown("right") && counter.active == true) {
            setLocation(getX() + speed, getY());
            if (counter.vel > 0) {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() + 64);
            }
            else {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() - 64);
            }
        }
        if (Greenfoot.isKeyDown("left") && counter.active == true) {
            setLocation(getX() - speed, getY());
            if (counter.vel > 0) {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() + 64);
            }
            else {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() - 64);
            }
        }
        if (Greenfoot.isKeyDown("up") && counter.active == true) {
            setLocation(getX(), getY() - speed);
            if (counter.vel > 0) {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() + 64);
            }
            else {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() - 64);
            }
        }
        if (Greenfoot.isKeyDown("down") && counter.active == true) {
            setLocation(getX(), getY() + speed);
            if (counter.vel > 0) {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() + 64);
            }
            else {
                ((flame)getWorld().getObjects(flame.class).get(0)).setLocation(getX(), getY() - 64);
            }
        }
        load1 -= 1;
        if (isTouching(Bomber.class)) {
            getWorld().removeObject(getOneIntersectingObject(Bomber.class));
            shield.shield(3);
        }
        if (isTouching(Fighter.class)) {
            getWorld().removeObject(getOneIntersectingObject(Fighter.class));
            shield.shield(2);
        }
        //if (isTouching(Gunship.class)) {
        //    (Gunship)(getWorld().getObjects(Gunship.class).get(0)).health -= 12;
        //    shield.shield(3);
        //    setLocation(getX(), getY() - 10);
        //}
        if (isTouching(FShot.class)) {
            FShot fshot = (FShot)getOneIntersectingObject(FShot.class);
            if (fshot.destroyed == false) {
                shield.shield(1);
                fshot.destroy();
            }
        }
        if (isTouching(GShot.class) && Greenfoot.getRandomNumber(5) == 1) {
            GShot gshot = (GShot)getOneIntersectingObject(GShot.class);
            if (gshot.destroyed == false) {
                shield.shield(1);
                gshot.destroy();
            }
        }
    }
    private void changeImg(int img, boolean alt) {
        if (alt == true) {
            setImage("p" + img + "alt.png");
        }
        else {
            setImage("p" + img + ".png");
        }
        image = img;
        
    }
}

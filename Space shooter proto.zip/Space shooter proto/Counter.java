
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The counter handles score and spawning enemies in
 * 
 * Oliver Hill
 * v0.2
 */
public class Counter extends Actor
{
    public int score;// the player's score
    private int count;// the frames since the last spawn event
    public int unicount;// a total count of how many frames have passed
    private int countneeded;// random variable, the number of frames needed for a new spawn event to occur
    private int ran;// random variable
    public boolean gunrdy; //determines whether a gunship can be spawned in or not
    private int x;
    public int stage = 1;
    public float vel; // velocity of the camera
    public boolean active;
    public int uniturn = 0;
    public int level = 1;
    public void addedToWorld(World MyWorld) {
        count = Greenfoot.getRandomNumber(300);
        countneeded = count + 90;
        GreenfootImage image = getImage();
        image.scale(1, 1);
        gunrdy = true;
        vel = 1;
        active = true;
    }
    /**
     * Act - do whatever the Counter wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Player player = (Player)getWorld().getObjects(Player.class).get(0);
        count += 1;
        unicount += 1;
        if (active) {
            if (count >= countneeded) {
                if (unicount < 3600) {// should be 3600
                    x = Greenfoot.getRandomNumber(1281);
                    if (-150 < x - player.getX()) {
                        x += 300;
                        if (x > 1280) {
                            x = 600;
                        }
                    }
                    else if (x - player.getX() < 150) {
                        x += 300;
                        if (x > 1280) {
                            x = 600;
                        }
                    }
                    getWorld().addObject(new Bomber(), x, 2);
                }
                else if (gunrdy == true) {
                    getWorld().addObject(new Gunship(), 640, 0);
                    gunrdy = false;
                }
                count = 0;
                countneeded = Greenfoot.getRandomNumber(300) + 180;
                if (unicount > 1100) {
                    ran = Greenfoot.getRandomNumber(3);
                    if (ran == 1) {
                        x = Greenfoot.getRandomNumber(1281);
                        if (player.getX() > 950) {
                            if (-300 < x - player.getX() && !(x - player.getX() > 300)) {
                                if (x >= player.getX()) {
                                    x += 400;
                                    if (x > 1280) {
                                        x = 500;
                                    }
                                }
                                else {
                                    x -= 400;
                                    if (x < 0) {
                                        x = 900;
                                    }
                                }
                            }
                        }
                        getWorld().addObject(new Fighter(), x, 650);
                    }
                }
            }
        }
        else {
            if (vel > -1) {
                vel -= 0.005;
            }
            else {
                active = true;
            }
            if (player.getRotation() != 180) {
                player.turn(1);
            }
            
        }
    }
    public void score(int addition)
    {
        score += addition;
    }
    public void nextLvl() {
        active = false;
        level = 2;
    }
}

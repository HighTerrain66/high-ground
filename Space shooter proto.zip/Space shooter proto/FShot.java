import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FShot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FShot extends Actor
{
    /**
     * Act - do whatever the FShot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int count = 14;
    public boolean destroyed = false;
    public void act() 
    {
        if (destroyed == false) {
            setLocation(getX(), getY() - 18);
        }
        if (isAtEdge()) {
            getWorld().removeObject((FShot)getWorld().getObjects(FShot.class).get(0));
        }
        if (destroyed == true) {
            count -= 1;
            if (count == 0) {
                getWorld().removeObject(this);
            }
        }
    }
    public void destroy()
    {
        setImage("fshot2.png");
        destroyed = true;
    }  
}

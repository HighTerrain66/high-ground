    import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
    
    /**
     * An enemy gunship. Compared to the standard bombers, this thing is far more durable and well defended. However, it's actual payload isn't much of an upgrade and the high manufacturing cost make this a rare sight.
     *  It has turret on the rear featuring two  fast firing long barreled laser cannons.
     * @author (your name) 
     * @version (a version number or a date)
     */
    public class Gunship extends Actor
    {
        public int health;
        private boolean destroyed;
        private int img;
        private int count;
        private int cycle;
        private int act;
        private int load;
        private int ammo;
        private boolean full;
        private int move;
        /**
         * Act - do whatever the Gunship wants to do. This method is called whenever
         * the 'Act' or 'Run' button gets pressed in the environment.
         */
        public void addedToWorld(World MyWorld)
        {
            setRotation(180);
            cycle = 50 + Greenfoot.getRandomNumber(50);
            count = 0;
            load = 16;
            act = 1;
            ammo = 0;
            full = false;
            img = 1;
            move = 70;
            health = 66 + 66;
        }
        public void act() 
        {
            Player player = (Player)getWorld().getObjects(Player.class).get(0);
            Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
            if (destroyed == false) {

                if (ammo < 1) {
                    full = false;
                }
                if (act == 1 && full == true) {
                    load += 1;
                    if (load > 16) {
                        getWorld().addObject(new GShot(), getX() + Greenfoot.getRandomNumber(5) - 2, getY() + 60);
                    }
                    ammo -= 1;
                }
                else if (act == 1) {
                    ammo += 1;
                    if (ammo > 149) {
                        full = true;
                    }
                }
                if (isTouching(Shot.class) && ((Shot)getWorld().getObjects(Shot.class).get(0)).destroyed == false){
                    ((Shot)getWorld().getObjects(Shot.class).get(0)).destroy();
                    health -= 8;
                    if (health < 1){
                        destroyed = true;
                    }
                        
                }
                if (move > 0) {
                    setLocation(getX(), getY() + 1);
                    move -= 1;
                }
            }
            else {
                count += 1;
                if (count == 8 && img < 20) {
                    changeImg(img + 1, false);
                    count = 0;
                }
                setLocation(getX(), getY() + 2);
                if (isAtEdge() && img >= 20) {
                    counter.nextLvl();
                    getWorld().removeObject(this);
                }
            }
        }
        private void changeImg(int image, boolean alt) {
            if (alt == true) {
                setImage("g" + image + "alt.png");
            }
            else {
                setImage("g" + image + ".png");
            }
            img = image;
            
        }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Shield here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shield extends Actor
{
    /**
     * Act - do whatever the Shield wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int shieldstr = 3;
    public int hull = 3;
    private int count = 0;
    public void act() 
    {
        if (shieldstr < 3) {
            count += 1;
            if (count > 249) {
                shieldstr += 1;
                shield(0);
                count = 0;
            }
        }
    }
    public void shield(int damage) {
        if (shieldstr > 0) {
            shieldstr -= damage;
            if (damage > shieldstr) {
                hull -= 1;
            }
        }
        else {
            hull -= damage;
        }
        if (shieldstr == 3 && hull == 3) {
            setImage("shield.png");
        }
        if (shieldstr == 2 && hull == 3) {
            setImage("shield23.png");
        }
        else if (shieldstr == 1 && hull == 3) {
            setImage("shield13.png");
        }
        else if (shieldstr < 1 && hull == 3) {
            setImage("shield03.png");
        }
        else if (shieldstr < 1 && hull == 2) {
            setImage("shield02.png");
        }
        else if (shieldstr == 1 && hull ==2) {
            setImage("shield12.png");
        }
        else if (shieldstr == 2 && hull == 2) {
            setImage("shield22.png");
        }
        else if (shieldstr == 3 && hull == 2) {
            setImage("shield32.png");
        }
        else if (hull  < 2) {
            setImage("shieldbroken.png");
        }
        if (hull < 1) {
            getWorld().removeObject((Player)getWorld().getObjects(Player.class).get(0));
        }
    }
}

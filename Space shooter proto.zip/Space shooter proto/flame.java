import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class flame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class flame extends Actor
{
    /**
     * Act - do whatever the flame wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int rand;
    public void act() 
    {
        Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
        rand = Greenfoot.getRandomNumber(4);
        if (rand <= 1) {
            setImage("flame1.png");
        }
        else if (rand == 2) {
            setImage("flame2.png");
        }
        else {
            setImage("flame3.png");
        }
        if (Greenfoot.isKeyDown("down")) {
            getImage().setTransparency(0);
        }
        if (counter.active == false) {
            getImage().setTransparency(0);
            
        }
        if (counter.level == 2) {
            setRotation(180);
        }
        else {
            setRotation(0);
        }
        
    }
}

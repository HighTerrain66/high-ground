import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FShot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GShot extends Actor
{
    /**
     * Act - do whatever the GShot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int count = 10;
    public boolean destroyed = false;
    private boolean init = true;
    public void act()
    {
        if (init == true) {
            Player player = (Player)getWorld().getObjects(Player.class).get(0);
            turnTowards(player.getX(),player.getY());
            turn(Greenfoot.getRandomNumber(13) - 6);
            init = false;
        }
        if (destroyed == false) {
            move(12);
        }
        if (isAtEdge()) {
            getWorld().removeObject((GShot)getWorld().getObjects(GShot.class).get(0));
        }
        if (destroyed == true) {
            count -= 1;
            if (count == 0) {
                getWorld().removeObject(this);
            }
        }
    }
    public void destroy()
    {
        setImage("gshot2.png");
        destroyed = true;
    }  
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class shot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shot extends Actor
{
    /**
     * Act - do whatever the shot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int count = 10;
    public boolean destroyed = false;
    private void Shot()
    {
        setImage("shot1.png");
    }
    public void act() 
    {
        Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
        if (destroyed == false && counter.level == 1) {
            setLocation(getX(), getY() - 18);
        }
        else if (destroyed == false) {
            setLocation(getX(), getY() + 18);
        }
        if (isAtEdge()) {
            getWorld().removeObject((Shot)getWorld().getObjects(Shot.class).get(0));
        }
        if (destroyed == true) {
            count -= 1;
            if (count == 0) {
                getWorld().removeObject(this);
            }
        }
    }
    public void destroy()
    {
        setImage("shot2.png");
        destroyed = true;
    }
}

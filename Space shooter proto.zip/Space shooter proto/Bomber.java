import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * An enemy bomber. It has one main engine and six vectoring pods that can be used for VTOL operations or to make in flight maneuvers without losing speed. Armed with six missiles, you don't want to let this slip past.
 * 
 * Oliver Hill
 * v0.2
 */
public class Bomber extends Actor
{
    /**
     * Act - do whatever the Bomber wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int health;
    private boolean destroyed;
    private int img;
    private int count;
    private int mspeed = 1;
    private int ran;
    private int rand;
    private int turn = 6;
    public void addedToWorld(World MyWorld)
    {
        setRotation(180);
        destroyed = false;
        health = 12;
        img = 1;
        count = 8;
        ran = Greenfoot.getRandomNumber(2);
        if (ran == 1) {
            turn = turn * -1;
        }
    }
    public void act() 
    {
        setLocation(getX(), getY() + mspeed);
        if(destroyed == true){
            
            if(count > 7 && img < 24) {
                changeImg(img + 1, false);
                if(img == 2) {
                    setImage("b2.png");
                    mspeed += 1;
                }
                if(img == 17) {
                    setImage("b17.png");
                    mspeed = 3;
                    turn(turn);
                }
                if (img > 17 && img < 25) {
                    turn(turn);
                }
                
                
                count = 0;
            }
            else if (count > 7 && img >= 24) {
                turn(turn / 2);
                count = 0;
            }
            if (getY() > 718) {
                getWorld().removeObject(this);
            }
        }
        else{
            
            if (isTouching(Shot.class) && ((Shot)getWorld().getObjects(Shot.class).get(0)).destroyed == false){
                ((Shot)getWorld().getObjects(Shot.class).get(0)).destroy();
                health -= 8;
                if (health < 1){
                    destroyed = true;
                }
                
            }
            if (isTouching(Bomber.class)) {
                health = 0;
                destroyed = true;
            }
            if (isTouching(Fighter.class)) {
                health = 0;
                destroyed = true;
            }
            Player player = (Player)getWorld().getObjects(Player.class).get(0);
            if (player.getX() > getX()) {
                if (player.getX() - getX() < 300 && getX() > 80) {
                    setLocation(getX() - 2, getY());
                }
            }
            else if (player.getX() < getX() && getX() < 1200) {
                if (getX() - player.getX() < 300) {
                    setLocation(getX() + 2, getY());
                }
            }
            rand = Greenfoot.getRandomNumber(4);
            if (rand <= 1) {
                changeImg(1, false);
            }
            else if (rand == 2) {
                changeImg(1, true);
            }
            else{
                changeImg(2, true);
            }
            if (getY() > 718) {
                getWorld().removeObject(this);
            }
        }
        count += 1;
    }
    private void changeImg(int image, boolean alt) {
        if (alt == true) {
            setImage("b" + image + "alt.png");
        }
        else {
            setImage("b" + image + ".png");
        }
        img = image;
        
    }
        
        
}

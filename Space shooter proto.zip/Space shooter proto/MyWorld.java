import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.List;
import java.util.ArrayList;
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1280, 720, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    
    List list = new ArrayList();
    private void prepare()
    {
        for(int i=1; i<(20+ Greenfoot.getRandomNumber(22)); i++)
        {
            addObject(new Star(), Greenfoot.getRandomNumber(1281), Greenfoot.getRandomNumber(721));
        }
        flame flame = new flame();
        addObject(flame,584,705);
        Player Player = new Player();
        addObject(Player,583,652);
        Bomber bomber = new Bomber();
        addObject(bomber,798,103);
        Counter counter2 = new Counter();
        addObject(counter2, 1195, 451);
        flame.setLocation(584, 716);
        Shield shield = new Shield();
        addObject(shield,40,41);
        FShot fShot = new FShot();
        addObject(fShot,1255,4);
    }
}

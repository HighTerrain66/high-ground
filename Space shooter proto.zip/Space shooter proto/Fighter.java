import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * An enemy fighter. Armed with quad wing mounted laser cannons and a slight superstructure, this is capable of reaching great speeds for short periods of time. However, durability and visibility are more than lacking, as well as coordination...
 * 
 * Oliver Hill 
 * v0.2
 */
public class Fighter extends Actor
{
    private int health;
    private boolean destroyed;
    private int img;
    private int count;
    private int mspeed = -2;
    private int rand;
    private int charge;
    public void addedToWorld(World MyWorld)
    {
        destroyed = false;
        health = 6;
        img = 1;
        count = 8;
    }
    public void act() 
    {
        Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
        charge += 1;
        if (destroyed == false) {
            if (isTouching(Shot.class) && ((Shot)getWorld().getObjects(Shot.class).get(0)).destroyed == false){
                    ((Shot)getWorld().getObjects(Shot.class).get(0)).destroy();
                    health -= 8;
                    if (health < 1){
                        destroyed = true;
                        img = 1;
                    }
                    
            }
            if (isTouching(GShot.class) && ((GShot)getWorld().getObjects(GShot.class).get(0)).destroyed == false){
                    ((GShot)getWorld().getObjects(GShot.class).get(0)).destroy();
                    health -= 1;
                    if (health < 1){
                        destroyed = true;
                        img = 1;
                    }
                    
            }
            if (isTouching(Bomber.class)) {
                health = 0;
                destroyed = true;
                img = 1;
            }
            if (isTouching(Fighter.class)) {
                health = 0;
                destroyed = true;
                img = 1;
            }
            Player player = (Player)getWorld().getObjects(Player.class).get(0);
            if (player.getY() < getY() && counter.active == true) {
                if (player.getX() > getX()) {
                    if (player.getX() - getX() > 4) {
                        setLocation(getX() + 4, getY());
                    }
                }
                else if (player.getX() < getX()) {
                    if (getX() - player.getX() > 4) {
                        setLocation(getX() - 4, getY());
                    }
                  
                }
                
            }
            else if (counter.active == true){
                if (player.getX() > getX()) {
                    if (player.getX() - getX() > 4) {
                        setLocation(getX() - 4, getY());
                    }
                }
                else if (player.getX() < getX()) {
                    if (getX() - player.getX() > 4) {
                        setLocation(getX() + 4, getY());
                    }
                }
            }
            if (getX() - player.getX() < 15 && player.getX() - getX() < 15 && charge > 12 && (counter.active = true)) {
                rand = Greenfoot.getRandomNumber(3);
                if (rand == 1) {
                    getWorld().addObject(new FShot(), getX() + Greenfoot.getRandomNumber(13) + 10, getY());
                }
                else {
                    getWorld().addObject(new FShot(), getX() - Greenfoot.getRandomNumber(13) - 10, getY());
                }
                
                charge = 0;
            }
            if (player.getY() - getY() < -250) {
                setLocation(getX(), getY() - 4);
            }
            else if (player.getY() - getY() > 0) {
                setLocation(getX(), getY() + 3);
            }
            
            rand = Greenfoot.getRandomNumber(4);
            if (rand <= 1) {
                changeImg(1, false);
            }
            else if (rand == 2) {
                changeImg(1, true);
            }
            else{
                changeImg(2, true);
            }
        }
        else {
            if(count > 5 && img < 11) {
                changeImg(img + 1, false);
                if(img == 6) {
                    mspeed -= 2;
                }
                if(img == 11) {
                    mspeed -= 2;
                }
                count = 0;
            }
            if(!isAtEdge()) {
                setLocation(getX(), getY() - mspeed);
            }
            count += 1;
            if (isAtEdge()) {
                getWorld().removeObject(this);
            }
            
        }
    }
    private void changeImg(int image, boolean alt) {
        if (alt == true) {
            setImage("f" + image + "alt.png");
        }
        else {
            setImage("f" + image + ".png");
        }
        img = image;
        
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class star here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Star extends Actor
{
    /**
     * Act - do whatever the star wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int speed;
    private int ran;
    public void addedToWorld(World MyWorld)
    {
        ran = Greenfoot.getRandomNumber(10) + 1;
        if (ran < 6) {
            setImage("star1.png");
        }
        else if (ran <  9) {
            setImage("star2.png");
        }
        else {
            setImage("star3.png");
        }
        ran = Greenfoot.getRandomNumber(10) + 1;
        GreenfootImage image = getImage();
        image.scale(image.getWidth() - (5 + ran), image.getHeight() - (5 + ran));
        speed = (int)(60/ran);
    }
    public void act() 
    {
        Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
        setLocation(getX(), getY() + (int)(speed * ((Counter)getWorld().getObjects(Counter.class).get(0)).vel));
        if (isAtEdge() && getY() < 1000 && counter.vel > 0) {
            setLocation(Greenfoot.getRandomNumber(1280), 0);
            ran = Greenfoot.getRandomNumber(21);
            if (ran < 12) {
                setImage("star1.png");
            }
            else if (ran <  15) {
                setImage("star2.png");
            }
            else {
                setImage("star3.png");
            }
            ran = Greenfoot.getRandomNumber(10) + 1;
            GreenfootImage image = getImage();
            image.scale(image.getWidth() - (5 + ran), image.getHeight() - (5 + ran));
            speed = 60/ran;
        }
        else if (isAtEdge() && getY() < 1000 && counter.vel < 0) {
            setLocation(Greenfoot.getRandomNumber(1280), 720);
            ran = Greenfoot.getRandomNumber(21);
            if (ran < 12) {
                setImage("star1.png");
            }
            else if (ran <  15) {
                setImage("star2.png");
            }
            else {
                setImage("star3.png");
            }
            ran = Greenfoot.getRandomNumber(10) + 1;
            GreenfootImage image = getImage();
            image.scale(image.getWidth() - (5 + ran), image.getHeight() - (5 + ran));
            speed = 60/ran;
        }
        
    }    
}

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HelloThereImage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HelloThereImage))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lbl2 = New System.Windows.Forms.Label()
        Me.ScoreLbl = New System.Windows.Forms.Label()
        Me.HelpLbl = New System.Windows.Forms.Label()
        Me.CounterLbl = New System.Windows.Forms.Label()
        Me.StartBtn = New System.Windows.Forms.Button()
        Me.TitleLbl = New System.Windows.Forms.Label()
        Me.InfoLbl1 = New System.Windows.Forms.Label()
        Me.InfoLbl2 = New System.Windows.Forms.Label()
        Me.InfoLbl3 = New System.Windows.Forms.Label()
        Me.CorrectLbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.AccessibleName = "Btn1"
        Me.Button1.BackColor = System.Drawing.Color.Red
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.Button1.Location = New System.Drawing.Point(595, 486)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(158, 32)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Submit"
        Me.Button1.UseVisualStyleBackColor = False
        Me.Button1.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.TextBox1.Location = New System.Drawing.Point(76, 486)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(521, 32)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Visible = False
        '
        'Label1
        '
        Me.Label1.AccessibleName = "Lbl"
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.Label1.Location = New System.Drawing.Point(0, 486)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 32)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Quote:"
        Me.Label1.Visible = False
        '
        'Lbl2
        '
        Me.Lbl2.AutoSize = True
        Me.Lbl2.BackColor = System.Drawing.Color.White
        Me.Lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Lbl2.Location = New System.Drawing.Point(452, -1)
        Me.Lbl2.Name = "Lbl2"
        Me.Lbl2.Size = New System.Drawing.Size(0, 29)
        Me.Lbl2.TabIndex = 4
        '
        'ScoreLbl
        '
        Me.ScoreLbl.AutoSize = True
        Me.ScoreLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ScoreLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!)
        Me.ScoreLbl.Location = New System.Drawing.Point(-2, -1)
        Me.ScoreLbl.Name = "ScoreLbl"
        Me.ScoreLbl.Size = New System.Drawing.Size(138, 39)
        Me.ScoreLbl.TabIndex = 5
        Me.ScoreLbl.Text = "Score: 0"
        Me.ScoreLbl.Visible = False
        '
        'HelpLbl
        '
        Me.HelpLbl.AutoSize = True
        Me.HelpLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.HelpLbl.Location = New System.Drawing.Point(39, 220)
        Me.HelpLbl.Name = "HelpLbl"
        Me.HelpLbl.Size = New System.Drawing.Size(0, 29)
        Me.HelpLbl.TabIndex = 6
        '
        'CounterLbl
        '
        Me.CounterLbl.AutoSize = True
        Me.CounterLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.CounterLbl.Location = New System.Drawing.Point(1, 38)
        Me.CounterLbl.Name = "CounterLbl"
        Me.CounterLbl.Size = New System.Drawing.Size(0, 26)
        Me.CounterLbl.TabIndex = 7
        Me.CounterLbl.Visible = False
        '
        'StartBtn
        '
        Me.StartBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.StartBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.StartBtn.Location = New System.Drawing.Point(377, 422)
        Me.StartBtn.Name = "StartBtn"
        Me.StartBtn.Size = New System.Drawing.Size(128, 58)
        Me.StartBtn.TabIndex = 8
        Me.StartBtn.Text = "Start"
        Me.StartBtn.UseVisualStyleBackColor = True
        '
        'TitleLbl
        '
        Me.TitleLbl.AutoSize = True
        Me.TitleLbl.BackColor = System.Drawing.Color.Black
        Me.TitleLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!)
        Me.TitleLbl.ForeColor = System.Drawing.Color.White
        Me.TitleLbl.Location = New System.Drawing.Point(171, -1)
        Me.TitleLbl.Name = "TitleLbl"
        Me.TitleLbl.Size = New System.Drawing.Size(524, 73)
        Me.TitleLbl.TabIndex = 9
        Me.TitleLbl.Text = "The Prequel Test"
        '
        'InfoLbl1
        '
        Me.InfoLbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.InfoLbl1.Location = New System.Drawing.Point(97, 102)
        Me.InfoLbl1.Name = "InfoLbl1"
        Me.InfoLbl1.Size = New System.Drawing.Size(591, 60)
        Me.InfoLbl1.TabIndex = 10
        Me.InfoLbl1.Text = "Enter the quote being said in the image that is shown by typing it into the text " &
    "box at the bottom"
        '
        'InfoLbl2
        '
        Me.InfoLbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.InfoLbl2.Location = New System.Drawing.Point(97, 162)
        Me.InfoLbl2.Name = "InfoLbl2"
        Me.InfoLbl2.Size = New System.Drawing.Size(591, 32)
        Me.InfoLbl2.TabIndex = 11
        Me.InfoLbl2.Text = "Click the submit button or press enter to submit your answer"
        '
        'InfoLbl3
        '
        Me.InfoLbl3.BackColor = System.Drawing.SystemColors.Info
        Me.InfoLbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.InfoLbl3.Location = New System.Drawing.Point(564, 194)
        Me.InfoLbl3.Name = "InfoLbl3"
        Me.InfoLbl3.Size = New System.Drawing.Size(307, 137)
        Me.InfoLbl3.TabIndex = 12
        Me.InfoLbl3.Text = "The quote must be gramatically correct, but it does not need to be force-sensitiv" &
    "e(case).              May the force be with you!"
        '
        'CorrectLbl
        '
        Me.CorrectLbl.AutoSize = True
        Me.CorrectLbl.BackColor = System.Drawing.Color.Black
        Me.CorrectLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!)
        Me.CorrectLbl.ForeColor = System.Drawing.Color.White
        Me.CorrectLbl.Location = New System.Drawing.Point(300, 258)
        Me.CorrectLbl.Name = "CorrectLbl"
        Me.CorrectLbl.Size = New System.Drawing.Size(292, 37)
        Me.CorrectLbl.TabIndex = 9
        Me.CorrectLbl.Text = "GOOOOOOOOD..."
        Me.CorrectLbl.Visible = False
        '
        'HelloThereImage
        '
        Me.AccessibleName = "hek"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(897, 517)
        Me.Controls.Add(Me.CorrectLbl)
        Me.Controls.Add(Me.InfoLbl3)
        Me.Controls.Add(Me.InfoLbl2)
        Me.Controls.Add(Me.InfoLbl1)
        Me.Controls.Add(Me.TitleLbl)
        Me.Controls.Add(Me.StartBtn)
        Me.Controls.Add(Me.CounterLbl)
        Me.Controls.Add(Me.HelpLbl)
        Me.Controls.Add(Me.ScoreLbl)
        Me.Controls.Add(Me.Lbl2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "HelloThereImage"
        Me.Text = "Hello there!"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Lbl2 As System.Windows.Forms.Label
    Friend WithEvents ScoreLbl As System.Windows.Forms.Label
    Friend WithEvents HelpLbl As System.Windows.Forms.Label
    Friend WithEvents CounterLbl As System.Windows.Forms.Label
    Friend WithEvents StartBtn As Button
    Friend WithEvents TitleLbl As Label
    Friend WithEvents InfoLbl1 As Label
    Friend WithEvents InfoLbl2 As Label
    Friend WithEvents InfoLbl3 As Label
    Friend WithEvents CorrectLbl As Label
End Class
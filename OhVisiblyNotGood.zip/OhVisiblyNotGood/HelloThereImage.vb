﻿' By Oliver Hill, otherwise known as HighTerrain66
' This is the beta version of a piece of software designed to aid in one's education in quotes from the Star Wars prequels
'-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
'          _______  _        _        _______ 
'|\     /|(  ____ \( \      ( \      (  ___  )
'| )   ( || (    \/| (      | (      | (   ) |
'| (___) || (__    | |      | |      | |   | |
'|  ___  ||  __)   | |      | |      | |   | |
'| (   ) || (      | |      | |      | |   | |
'| )   ( || (____/\| (____/\| (____/\| (___) |
'|/     \|(_______/(_______/(_______/(_______)
' _______           _______  _______  _______  _ 
'\__   __/|\     /|(  ____ \(  ____ )(  ____ \( )
'   ) (   | )   ( || (    \/| (    )|| (    \/| |
'   | |   | (___) || (__    | (____)|| (__    | |
'   | |   |  ___  ||  __)   |     __)|  __)   | |
'   | |   | (   ) || (      | (\ (   | (      (_)
'   | |   | )   ( || (____/\| ) \ \__| (____/\ _ 
'   )_(   |/     \|(_______/|/   \__/(_______/(_)
'-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
' This is a variant of the prequel quote test application in which you must state the quote that is being said in an image instead of stating the reply to a given quote. (this version is far more sophisticated than the reply version)
' The quote isn't case sensitive but in some rare cases punctuation accuracy is needed
' If you have no idea what these images are or what these quotes mean, watch the Star Wars prequels(you don't have to watch the phantom menace as that is actually a bad film).
' After the first image a random image will be displayed.
' By answering correctly you gain score- after you have attempted all of the random series, you are given a jedi rank
' Furthermore, when you have attempted all the images, the last image you failed will be displayed alongside its quote in order to help you learn.
' The amount of score you get from answering depends on the time you managed to answer in
' If you take a long time to enter a short quote, you get less score.
Public Class HelloThereImage
    Public Declare Sub Sleep Lib "kernel32" Alias "Sleep" (ByVal dwMilliseconds As Long)
    Dim stage As Integer = 1 ' stage determines which reply must be used to move to the next stage
    Dim oldStage As Integer = 1 ' a variable to help with debugging by showing the previous stage
    Dim ran As Integer = 0 ' a random integer that determines the next stage
    Dim completed(0) As Integer ' a list containing the previously completed stages in order to prevent a repeat
    Dim failed As Integer '  stores the number of the last stage the user failed; the image of this stage and its quote are shown at the end
    Dim score As Integer = 0 ' Score: is obtained by answering correctly in a short period of time. Score determines the rank given at the end.
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HelloThereImage)) ' Reference to the projects resources to allow new background images to be referenced
    Dim fail As Integer '  a random number that determines what reply the user will receive upon answering incorrectly
    Dim counter As Integer ' increases by 1 every 1000ms, determines the penalty to score received when an answer is entered late. is reset when a quote is entered.
    Dim WithEvents Timer1 As New Timer ' the timer object that ticks every 1000ms and increases the counter by 1 each time
    Dim penalty As Integer = 0 ' is determined by the counter variable then is subtracted from the score gained after a correct quote is entered
    Dim oldScore As Integer = 0 ' is used to compare the score before addition to the score after addition to ensure that the score won't be reduced on a correct answer
    Dim totalCount As Integer = 0
    Dim correctTime As Integer = 0
    Dim ran2 As Integer = 1
    Sub Start()
        StartBtn.Text = CStr(CInt(StartBtn.Text) - 1) ' decrements the counter on the start button
        If counter > 2 Then ' if the main counter's value is greater than 2(if 3 seconds have passed since the clicking of the submit button)
            counter = 0 ' resets the main counter
            Button1.Enabled = True ' enables the submit button, effectively starting the test
            CounterLbl.Text = "0"
            CounterLbl.Visible = True ' makes the counter display visible
            StartBtn.Dispose() ' unloads all assets relevant to the start button
            TitleLbl.Dispose() ' guess
            totalCount = 0 ' resets the total count so the 3 second in which the user cannot submit an answer are not counted
        End If

    End Sub
    Sub Proceed() ' is called after a stage is completed
        Randomize()
        Console.WriteLine(completed.Length) ' outputs the length of the completed list to the console for debugging
        oldStage = stage
        If completed.Length < 19 Then
            Console.WriteLine("Main sequence") 'purely for debugging
            Do Until False ' loop for obtaining a random stage that has not already been completed
                ran = CInt((19 - 2 + 1) * Rnd() + 2) ' assigns a random integer to ran
                If Array.IndexOf(completed, ran) < 0 Then ' if ran is not in the completed list
                    Console.WriteLine("Not yet done")
                    stage = ran ' the stage is set to the random integer
                    If stage <> oldStage Then 'if the stage isn't the last stage(probably not necessary)
                        Exit Do 'end the loop and continue with the program
                    End If
                End If
                Console.WriteLine("Already done") ' if the loop is not exited it is clear that the random integer was equal to the number of an already completed stage
            Loop
        Else ' when enough stages have been completed, the scoring begins
            Console.WriteLine("Scoring:") ' these three lines are purely for debug
            Console.WriteLine(score)
            Console.WriteLine("----------------------------")
            Timer1.Stop() ' stops the timer
            CounterLbl.Text = "Total time: " & totalCount ' replaces the timer display with the total time the user has taken to finish
            If score < 0 Then ' all of these lines are for ranking; a score between 1301 and 1200 will give one a seat on the council, but they will not be granted the rank of master
                ScoreLbl.Text = "Rank: So uncivilised"
            ElseIf score < 451 And score > -1 Then
                ScoreLbl.Text = "Rank: Youngling"
            ElseIf score < 801 And score > 450 Then
                ScoreLbl.Text = "Rank: Padawan"
            ElseIf score < 1201 And score > 800 Then
                ScoreLbl.Text = "Rank: Jedi Knight"
            ElseIf score < 1301 And score > 1200 Then
                ScoreLbl.Text = "Rank: On the council but not a master"
            ElseIf score < 1501 And score > 1300 Then
                ScoreLbl.Text = "Rank: Jedi Master"
            ElseIf score < 1800 And score > 1500 Then
                ScoreLbl.Text = "Rank: Council member"
            Else
                ScoreLbl.Text = "Rank: The Chosen One"
            End If
            If score > 700 Then 'the user is given the oppurtunity to enter a certain quote for even more points if they got more than 700 score
                stage = 20
            End If
            Help()


        End If
        Console.WriteLine("Proceeding") ' again, these 4 lines are for debug
        Console.WriteLine(oldStage)
        Console.WriteLine(stage)
        Console.WriteLine("---------------------------------")

        If stage = 2 Then ' this section sets the background image according to the randomly selected stage
            Me.BackgroundImage = My.Resources.senate
            Console.WriteLine("treason")
            Console.WriteLine(Me.BackgroundImage)
        ElseIf stage = 3 Then
            Me.BackgroundImage = My.Resources.sand
            Console.WriteLine(Me.BackgroundImage)
        ElseIf stage = 4 Then
            Me.BackgroundImage = My.Resources.ohnotgood
            Console.WriteLine("cable 'round the leg")
            Console.WriteLine(Me.BackgroundImage)
        ElseIf stage = 5 Then
            Console.WriteLine("on the council but not a master")
            Me.BackgroundImage = My.Resources.seat
            Console.WriteLine(Me.BackgroundImage)
        ElseIf stage = 6 Then
            Me.BackgroundImage = My.Resources.pridefall
            Console.WriteLine("doubled powers")
        ElseIf stage = 7 Then
            Me.BackgroundImage = My.Resources.wookiees
        ElseIf stage = 8 Then
            Me.BackgroundImage = My.Resources.youdie
        ElseIf stage = 9 Then
            Me.BackgroundImage = My.Resources.yep
        ElseIf stage = 10 Then
            Me.BackgroundImage = My.Resources.highground
        ElseIf stage = 11 Then
            Me.BackgroundImage = My.Resources.halfship
        ElseIf stage = 12 Then
            Me.BackgroundImage = My.Resources.system
        ElseIf stage = 13 Then
            Me.BackgroundImage = My.Resources.uncivilised
        ElseIf stage = 14 Then
            Me.BackgroundImage = My.Resources.surprise
        ElseIf stage = 15 Then
            Me.BackgroundImage = My.Resources.democracy
        ElseIf stage = 16 Then
            Me.BackgroundImage = My.Resources.party
        ElseIf stage = 17 Then
            Me.BackgroundImage = My.Resources.unfair
        ElseIf stage = 18 Then
            Me.BackgroundImage = My.Resources.dontthinkso
        ElseIf stage = 19 Then
            Me.BackgroundImage = My.Resources.abandon
        ElseIf stage = 20 Then
            Button1.Text = "(you won?)"
        End If
    End Sub
    Sub Nter() ' the function that is called when a quote (or misquote) is entered
        oldScore = score
        If stage = 1 And (UCase(TextBox1.Text) = "HELLO THERE!" Or UCase(TextBox1.Text) = "HELLO THERE") Then 'if stage 1 is fulfilled by entering the correct quote
            Lbl2.BackColor = Color.FromName("White")
            Lbl2.Text = "General Kenobi!"
            TextBox1.Text = "" ' clears the textbox
            completed(0) = 1 ' adds stage one to the list of completed stages
            If counter > 5 Then ' penalises the score if the user has taken more than 5 seconds
                penalty = 400 * (0.15 * (counter - 3)) ' sets the penalty to 15% of the highest score possibly obtained multiplied by the counter value -3
            End If
            score += 400 - penalty ' the score is added to by the highest possible score with the penalty (if there is one) subtracted from it
            If score < oldScore - 0 Then score = oldScore - 0 ' this stops score from being subtracted upon a correct answer
            counter = 0 ' the counter is reset
            penalty = 0 ' and the penalty is reset
            Console.WriteLine("General Kenobi!") ' for debugging only

        ElseIf stage = 2 And (UCase(TextBox1.Text) = "I AM THE SENATE" Or UCase(TextBox1.Text) = "I AM THE SENATE!" Or UCase(TextBox1.Text) = "I AM THE SENATE.") Then 'if stage 2 is fulfilled by entering the correct reply
            Lbl2.Text = "Not yet"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 2
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 3 And (UCase(TextBox1.Text) = "I DON'T LIKE SAND" Or UCase(TextBox1.Text) = "I DON'T LIKE SAND. IT'S COARSE, ROUGH, IRRITATING AND IT GETS EVERYWHERE" Or UCase(TextBox1.Text) = "I DON'T LIKE SAND. IT'S COARSE, ROUGH, AND IRRITATING, AND IT GETS EVERYWHERE." Or UCase(TextBox1.Text) = "I DON'T LIKE SAND.") Then 'if stage 3 is fulfilled by entering the correct reply
            Lbl2.Text = "Coarse, rough, irritating, gets everywhere"
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 3
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            If UCase(TextBox1.Text) = "I DON'T LIKE SAND. IT'S COARSE, ROUGH, IRRITATING AND IT GETS EVERYWHERE" Or UCase(TextBox1.Text) = "I DON'T LIKE SAND. IT'S COARSE, ROUGH, AND IRRITATING, AND IT GETS EVERYWHERE." Then
                score += 350 - penalty
                If score < oldScore - 0 Then score = oldScore - 0
            Else
                score += 200 - penalty
                If score < oldScore - 0 Then score = oldScore - 0
            End If
            counter = 0
            penalty = 0
            TextBox1.Text = ""


        ElseIf stage = 4 And (UCase(TextBox1.Text) = "OH NOT GOOD" Or UCase(TextBox1.Text) = "OH, NOT GOOD.") Then 'if stage 4 is fulfilled by entering the correct quote
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 4
            If counter > 4 Then
                penalty = 200 * (0.15 * (counter - 3))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 5 And (UCase(TextBox1.Text) = "TAKE A SEAT, YOUNG SKYWALKER" Or UCase(TextBox1.Text) = "TAKE A SEAT YOUNG SKYWALKER" Or UCase(TextBox1.Text) = "TAKE A SEAT, YOUNG SKYWALKER.") Then ' I'm not bothered to do a comment for everything
            Lbl2.Text = "Chosen one rekt"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 5
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 6 And (UCase(TextBox1.Text) = "GOOD. TWICE THE PRIDE, DOUBLE THE FALL" Or UCase(TextBox1.Text) = "GOOD. TWICE THE PRIDE, DOUBLE THE FALL." Or UCase(TextBox1.Text) = "GOOD, TWICE THE PRIDE, DOUBLE THE FALL" Or UCase(TextBox1.Text) = "GOOD, TWICE THE PRIDE, DOUBLE THE FALL." Or UCase(TextBox1.Text) = "GOOD TWICE THE PRIDE DOUBLE THE FALL") Then
            Lbl2.Text = "2Pride2Fall"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 6
            If counter > 10 Then ' longer quotes give greater score and allow more time to complete
                penalty = 250 * (0.25 * ((counter - 9)))
            End If
            score += 300 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 7 And UCase(TextBox1.Text) = "WHAT ABOUT THE DROID ATTACK ON THE WOOKIEES?" Then
            Lbl2.Text = "It is critical we send an attack group there immediately"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 7
            If counter > 7 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 8 And UCase(TextBox1.Text) = "NO, NO, YOU WILL DIE!" Then
            Lbl2.Text = "P = 9999999GW"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 8
            If counter > 5 Then
                penalty = 250 * (0.15 * (counter - 4))
            End If
            score += 250 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 9 And (UCase(TextBox1.Text) = "YEP" Or UCase(TextBox1.Text) = "YUP" Or UCase(TextBox1.Text) = "YEP!" Or UCase(TextBox1.Text) = "YUP!" Or UCase(TextBox1.Text) = "YEP." Or UCase(TextBox1.Text) = "YUP.") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 9
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 10 And (UCase(TextBox1.Text) = "IT'S OVER ANAKIN, I HAVE THE HIGH GROUND!" Or UCase(TextBox1.Text) = "IT'S OVER ANAKIN. I HAVE THE HIGH GROUND!" Or UCase(TextBox1.Text) = "IT'S OVER ANAKIN! I HAVE THE HIGH GROUND!") Then
            Lbl2.Text = "Jedi rekt"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 10
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 11 And (UCase(TextBox1.Text) = "NOT TO WORRY, WE ARE STILL FLYING HALF A SHIP" Or UCase(TextBox1.Text) = "NOT TO WORRY, WE ARE STILL FLYING HALF A SHIP." Or UCase(TextBox1.Text) = "NOT TO WORRY, WE'RE STILL FLYING HALF A SHIP" Or UCase(TextBox1.Text) = "NOT TO WORRY, WE'RE STILL FLYING HALF A SHIP.") Then
            Lbl2.Text = "happy landing incoming"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 11
            If counter > 5 Then
                penalty = 250 * (0.15 * (counter - 4))
            End If
            score += 250 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 12 And (UCase(TextBox1.Text) = "I DON'T THINK THE SYSTEM WORKS" Or UCase(TextBox1.Text) = "I DON'T THINK THE SYSTEM WORKS.") Then
            Lbl2.Text = "lucas groves"
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 12
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 13 And (UCase(TextBox1.Text) = "SO UNCIVILISED" Or UCase(TextBox1.Text) = "SO UNCIVILISED." Or UCase(TextBox1.Text) = "SO UNCIVILIZED") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 13
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 14 And (UCase(TextBox1.Text) = "A SURPRISE TO BE SURE, BUT A WELCOME ONE" Or UCase(TextBox1.Text) = "A SURPRISE TO BE SURE, BUT A WELCOME ONE.") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 14
            If counter > 7 Then
                penalty = 200 * (0.15 * (counter - 6))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 15 And (UCase(TextBox1.Text) = "I LOVE DEMOCRACY" Or UCase(TextBox1.Text) = "I LOVE DEMOCRACY." Or UCase(TextBox1.Text) = "I LOVE DEMOCRACY. I LOVE THE REPUBLIC." Or UCase(TextBox1.Text) = "I LOVE DEMOCRACY. I LOVE THE REPUBLIC" Or UCase(TextBox1.Text) = "I LOVE DEMOCRACY, I LOVE THE REPUBLIC" Or UCase(TextBox1.Text) = "I LOVE DEMOCRACY, I LOVE THE REPUBLIC.") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 15
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 16 And (UCase(TextBox1.Text) = "THIS PARTY'S OVER" Or UCase(TextBox1.Text) = "THIS PARTY'S OVER." Or UCase(TextBox1.Text) = "THIS PARTY'S OVER!") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 16
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 17 And (UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS. IT'S UNFAIR." Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS! IT'S UNFAIR!" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS. IT'S UNFAIR" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS. IT'S UNFAIR!" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS, IT'S UNFAIR!" Or UCase(TextBox1.Text) = "THIS IS OUTRAGEOUS, IT'S UNFAIR.") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 17
            If counter > 7 Then
                penalty = 200 * (0.15 * (counter - 6))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 18 And (UCase(TextBox1.Text) = "OH I DON'T THINK SO" Or UCase(TextBox1.Text) = "OH I DON'T THINK SO!" Or UCase(TextBox1.Text) = "OH I DON'T THINK SO.") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 18
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 19 And (UCase(TextBox1.Text) = "TIME TO ABANDON SHIP" Or UCase(TextBox1.Text) = "TIME TO ABANDON SHIP!" Or UCase(TextBox1.Text) = "TIME TO ABANDON SHIP.") Then
            Lbl2.Text = ""
            TextBox1.Text = ""
            ReDim Preserve completed(completed.Length + 1)
            completed(completed.Length - 1) = 19
            If counter > 5 Then
                penalty = 200 * (0.15 * (counter - 4))
            End If
            score += 200 - penalty
            If score < oldScore - 0 Then score = oldScore - 0
            counter = 0
            penalty = 0

        ElseIf stage = 20 And UCase(TextBox1.Text) = "VICTORY YOU SAY OBI-WAN?" Or UCase(TextBox1.Text) = "VICTORY YOU SAY OBI WAN?" Then
            Lbl2.Text = "No, not victory. Begun, the Clone Wars have."
            score += 200
        Else 'if an incorrect reply is submitted
            If stage = 8 Then
                TextBox1.Text = "TAKE A SEAT"
                Threading.Thread.Sleep(1000) 'the user is forced to TAKE A SEAT
            Else
                Randomize()
                fail = CInt((100 - 1 + 1) * Rnd() + 1)
                If fail < 50 Then
                    TextBox1.Text = "Invalid answer"
                ElseIf fail < 90 Then
                    TextBox1.Text = "General Misquoti!"
                Else
                    TextBox1.Text = "The ability to speak does not make you intelligent."
                End If
                ReDim Preserve completed(completed.Length + 1)
                completed(completed.Length - 1) = stage
                failed = stage
            End If
            score -= 50
            counter = 0
        End If
        ScoreLbl.Text = "Score: " + CStr(score)
        If Not (score < oldScore) Then
            Randomize()
            ran2 = CInt((5 - 1 + 1) * Rnd() + 1)
            If ran2 = 1 Then
                CorrectLbl.Text = "GOOOOOOOD..."
            ElseIf ran2 = 2 Then
                CorrectLbl.Text = "Don't get cocky!"
            ElseIf ran2 = 3 Then
                CorrectLbl.Text = "A surprise to be sure, but a welcome one"
            ElseIf ran2 = 4 Then
                CorrectLbl.Text = "Ah, victory"
            Else
                CorrectLbl.Text = "Another happy landing"
            End If
            CorrectLbl.Visible = True
            correctTime = 2
        End If
        If stage = 20 Then
            If score < 0 Then ' all of these lines are for ranking; a score between 1301 and 1200 will give one a seat on the council, but they will not be granted the rank of master
                ScoreLbl.Text = "Rank: So uncivilised"
            ElseIf score < 451 And score > -1 Then
                ScoreLbl.Text = "Rank: Youngling"
            ElseIf score < 801 And score > 450 Then
                ScoreLbl.Text = "Rank: Padawan"
            ElseIf score < 1201 And score > 800 Then
                ScoreLbl.Text = "Rank: Jedi Knight"
            ElseIf score < 1301 And score > 1200 Then
                ScoreLbl.Text = "Rank: On the council but not a master"
            ElseIf score < 1501 And score > 1300 Then
                ScoreLbl.Text = "Rank: Jedi Master"
            ElseIf score < 1800 And score > 1500 Then
                ScoreLbl.Text = "Rank: Council member"
            Else
                ScoreLbl.Text = "Rank: The Chosen One"
            End If
        End If
        CounterLbl.Text = "0"
        Proceed()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click ' the reply button click event
        Dim Button1 As Button = DirectCast(sender, Button)
        Nter() ' submits the 
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If Button1.Enabled = True Then
            If e.KeyCode = Keys.Enter Then
                Nter() 'submits the contents of the textbox when the enter key is pressed
            ElseIf (TextBox1.Text = "Invalid answer" Or TextBox1.Text = "General Misquoti!" Or TextBox1.Text = "The ability to speak does not make you intelligent.") And e.KeyCode <> Keys.Enter Then
                TextBox1.Text = "" ' clears the textbox if one of the incorrect answer text fills the textbox and a key other than enter is pressed
            End If
        End If
    End Sub
    Sub Help() ' This is called when the user finishes, showing the image and the quote of the last stage they failed
        Console.WriteLine("Help")
        Console.WriteLine(failed)
        If failed = 1 Then
            HelpLbl.Text = "Hello there!"
        ElseIf failed = 2 Then
            HelpLbl.Text = "I am the Senate"
            Me.BackgroundImage = My.Resources.senate
        ElseIf failed = 3 Then
            HelpLbl.Text = "I don't like sand. It's coarse, rough, and irritating, and it gets everywhere."
            Me.BackgroundImage = My.Resources.sand
        ElseIf failed = 4 Then
            HelpLbl.Text = "Oh not good"
            Me.BackgroundImage = My.Resources.ohnotgood
        ElseIf failed = 5 Then
            HelpLbl.Text = "Take a seat, young Skywalker"
            Me.BackgroundImage = My.Resources.seat
        ElseIf failed = 6 Then
            HelpLbl.Text = "Good. Twice the pride, double the fall."
            Me.BackgroundImage = My.Resources.pridefall
        ElseIf failed = 7 Then
            HelpLbl.Text = "What about the droid attack on the wookiees?"
            Me.BackgroundImage = My.Resources.wookiees
        ElseIf failed = 8 Then
            HelpLbl.Text = "No, no, you will die!"
            Me.BackgroundImage = My.Resources.youdie
        ElseIf failed = 9 Then
            HelpLbl.Text = "Yep"
            Me.BackgroundImage = My.Resources.yep
        ElseIf failed = 10 Then
            HelpLbl.Text = "It's over Anakin, I have the high ground!"
            Me.BackgroundImage = My.Resources.highground
        ElseIf failed = 11 Then
            HelpLbl.Text = "Not to worry, we are still flying half a ship"
            Me.BackgroundImage = My.Resources.halfship
        ElseIf failed = 12 Then
            HelpLbl.Text = "I don't think the system works"
            Me.BackgroundImage = My.Resources.system
        ElseIf failed = 13 Then
            HelpLbl.Text = "So uncivilised"
            Me.BackgroundImage = My.Resources.uncivilised
        ElseIf failed = 14 Then
            HelpLbl.Text = "A surprise to be sure, but a welcome one."
            Me.BackgroundImage = My.Resources.surprise
        ElseIf failed = 15 Then
            HelpLbl.Text = "I love democracy"
            Me.BackgroundImage = My.Resources.democracy
        ElseIf failed = 16 Then
            HelpLbl.Text = "This party's over"
            Me.BackgroundImage = My.Resources.party
        ElseIf failed = 17 Then
            HelpLbl.Text = "This is outrageous. It's unfair!"
            Me.BackgroundImage = My.Resources.unfair
        ElseIf failed = 18 Then
            HelpLbl.Text = "This is outrageous. It's unfair!"
            Me.BackgroundImage = My.Resources.dontthinkso
        ElseIf failed = 19 Then
            HelpLbl.Text = "Time to abandon ship"
            Me.BackgroundImage = My.Resources.abandon
        End If
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick ' called every 1000ms
        counter = counter + 1 ' increases the counter by 1
        totalCount += 1 ' increase the total counter shown at the end by 1
        CounterLbl.Text = counter ' sets the text of the label used to display the counter's value to the value of the counter
        If Button1.Enabled = False Then ' if the test hasn't started yet
            Start() ' calls the start function which decrements the text on the start button and starts the test when the counter reaches 
        End If
        If correctTime > 0 Then
            correctTime -= 1
            If correctTime < 1 Then
                CorrectLbl.Visible = False
            End If
        End If
    End Sub

    Private Sub StartBtn_Click(sender As Object, e As EventArgs) Handles StartBtn.Click ' when the start button is clicked(the first time)
        If ScoreLbl.Visible = False Then
            InfoLbl1.Dispose() 'removes all assets for the first info label
            InfoLbl2.Dispose() ' removes all assets for the second info label
            InfoLbl3.Dispose() ' guess
            ScoreLbl.Visible = True ' makes the score label visible
            TextBox1.Visible = True ' enables the textbox so you can see it and enter text in it
            Button1.Visible = True ' makes the submit button visible
            Button1.Enabled = False ' stops the submit button from working so a quote can't be submitted
            Label1.Visible = True ' guess again
            TitleLbl.Text = "Get ready!" ' guess yet again
            Timer1.Interval = 1000 ' sets the timer to tick every 1000ms
            Timer1.Start() ' starts the timer
            TextBox1.Select() ' selects the text box automatically for the user
            StartBtn.Text = "4" ' sets the text of the start button to 4, not 3 as the value is subtracted from almost straight away, but it needs to be an integer in the first place to be subtracted from
            Start() ' calls the start function which decrements the text on the start button and starts the test when the counter reaches 
        End If
    End Sub
End Class
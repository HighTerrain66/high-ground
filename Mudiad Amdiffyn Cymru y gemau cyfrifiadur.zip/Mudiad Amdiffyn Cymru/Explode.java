import greenfoot.*;

/**
 * Write a description of class Explode here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explode extends Actor
{
    /**
     * Act - do whatever the Explode wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int boom = 0;
    public int timer = 0;
    public Explode() {
        getImage().setTransparency(0);
        getImage().scale(getImage().getWidth() + 15, getImage().getHeight() + 15);
    }
    public void act() 
    {
        if(boom == 1){
            timer += 1;
        }
        if (timer > 40) {
            getImage().setTransparency(0);
            boom = 0;
            timer = 0;
            setLocation(0, 0);
        }
    }    
    public void explodio() {
        setLocation(((Bom)getWorld().getObjects(Bom.class).get(0)).getX(), ((Bom)getWorld().getObjects(Bom.class).get(0)).getY());
        getImage().setTransparency(255);
        boom = 1;
    }
}

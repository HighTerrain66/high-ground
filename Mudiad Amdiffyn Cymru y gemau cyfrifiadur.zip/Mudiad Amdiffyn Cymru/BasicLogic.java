import greenfoot.*;

/**
 * Write a description of class BasicLogic here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BasicLogic extends Actor
{
    /**
     * Act - do whatever the BasicLogic wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public BasicLogic() 
    {
        getImage().setTransparency(0);
    }    
}

import greenfoot.*;

/**
 * Write a description of class Bom here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bom extends Actor
{
    /**
     * Act - do whatever the Bom wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Bom() {
        getImage().setTransparency(0);
    }
    public int timer = 0;
    public int plant = 0;
    public void act(){
        if (Greenfoot.isKeyDown("space") && plant == 0) {
            plant = 1;
            setLocation(((MAC)getWorld().getObjects(MAC.class).get(0)).getX() - 30, ((MAC)getWorld().getObjects(MAC.class).get(0)).getY());
            getImage().setTransparency(255);
        }
        if (plant == 1) {
            plantio();
        }
    }
    public void plantio() 
    {
        timer += 1;
        if(timer > 200){
            getImage().setTransparency(0);
            plant = 0;
            ((Explode)getWorld().getObjects(Explode.class).get(0)).explodio();
            timer = 0;
        }
    }    
}

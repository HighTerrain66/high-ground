import greenfoot.*;

/**
 * Write a description of class MAC here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MAC extends Actor
{
    /**
     * Act - do whatever the MAC wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int ground = 1;
    public int yv = 0;
    public MAC() {
        getImage().scale(getImage().getWidth() - 10, getImage().getHeight() - 6);
    }
    public void act() 
    {
        if(isTouching(Land.class)) {
            if (ground == 0) {
                yv = 0;
            }
            ground = 1;
        }
        else {
            if(isTouching(English.class)) {
                if (ground == 0) {
                yv = 0;
               }
               ground = 1;
            }
            else {
            ground = 0;
            }
        }
        
        if(Greenfoot.isKeyDown("up") && ground == 1) {
            yv = 16;
        }
        if (ground == 0) {
            yv = yv - 1;
        }
        if (isTouching(Explode.class) && ground == 0) {
            yv += 18;
        }
        if (yv > 25) {
            yv = 25;
        }
        setLocation(getX(), getY()-yv);
        if (((MACside)getWorld().getObjects(MACside.class).get(0)).touch == 1 && ((MACside2)getWorld().getObjects(MACside2.class).get(0)).touch == 1) {
            setLocation(getX(), getY()-4);
        }
        if (isTouching(BasicLogic.class)) {
            if (((CapelCelyn)getWorld()).lvl == 1){
                setLocation(116, 326);
            }
            if (((CapelCelyn)getWorld()).lvl == 2){
                setLocation(68, 639);
            }
            if (((CapelCelyn)getWorld()).lvl == 3){
                setLocation(73, 69);
            }
            if (((CapelCelyn)getWorld()).lvl == 4){
                setLocation(1234, 615);
            }
            if (((CapelCelyn)getWorld()).lvl == 5){
                setLocation(82,557);
            }
            
        }
    }
    public void left() {
        setLocation(getX()-5, getY());
    }
    public void right() {
        setLocation(getX()+5, getY());
    }
}

import greenfoot.*;

/**
 * Write a description of class MACside here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MACside2 extends Actor
{
    /**
     * Act - do whatever the MACside2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public MACside2() {
        getImage().setTransparency(0);
        getImage().scale(getImage().getWidth() - 6, getImage().getHeight() - 6);
    }
    public int touch = 0;
    public void act() 
    {
        if (isTouching(Land.class)) {
            touch = 1;
        }
        else {
            touch = 0;
        }
        if (Greenfoot.isKeyDown("right") && touch == 0) {
            setLocation(getX() - 3, getY());
            ((MAC)getWorld().getObjects(MAC.class).get(0)).right();
        }
        setLocation(((MAC)getWorld().getObjects(MAC.class).get(0)).getX() + 30, ((MAC)getWorld().getObjects(MAC.class).get(0)).getY());
    }    
}

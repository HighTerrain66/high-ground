import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TankYFuel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TankYFuel extends Actor
{
    /**
     * Act - do whatever the TankYFuel wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public TankYFuel() {
        getImage().scale(getImage().getWidth() - 120, getImage().getHeight() - 180);
    }
    public void act() 
    {
        
    }    
}
